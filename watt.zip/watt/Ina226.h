#define INA226_ADDR 0x40

void write16(uint8_t reg, uint16_t value) {
  Wire.beginTransmission(INA226_ADDR);
  Wire.write(reg);
  Wire.write(value >> 8);
  Wire.write(value & 0xFF);
  Wire.endTransmission();
}

uint16_t read16(uint8_t reg) {
  Wire.beginTransmission(INA226_ADDR);
  Wire.write(reg);
  Wire.endTransmission();

  Wire.requestFrom(INA226_ADDR, (uint8_t)2);
  return (Wire.read() << 8) | Wire.read();
}

float getVoltage() {
  uint16_t raw = read16(0x02);
  return raw * 1.25 / 1000.0; // volts
}

float getCurrent() {
  int16_t raw = (int16_t)read16(0x04);
  return raw * 0.0001; // calibré R100
}
