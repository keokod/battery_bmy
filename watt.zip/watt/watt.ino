#include <Wire.h>
#include <Pixel.h> // modèles chiffres, A et V
#include <ConfigI2C.h>
#include <Ina226.h>

float number = 0;        // valeur initiale
const unsigned long interval = 5;  // 25 ms entre chaque incrément
unsigned long lastUpdate = 0;



void clearBuffer() {
  for(int page=0; page<8; page++)
    for(int col=0; col<128; col++)
      screenBuffer[page][col] = 0x00;
}

void updateScreen() {
  for(int page=0; page<8; page++) {
    ssd1306Command(0xB0 + page);
    ssd1306Command(0x00);
    ssd1306Command(0x10);
    for(int col=0; col<128; col++)
      ssd1306Data(screenBuffer[page][col]);
  }
}

void drawPixel(int x, int y) {
  if(x<0 || x>=128 || y<0 || y>=64) return;
  int page = y / 8;
  int bit  = y % 8;
  screenBuffer[page][x] |= (1 << bit);
}

void drawCharZoomBuffer(int x0, int y0, uint8_t charData[8], int zoom=1) {
  for(int y=0; y<8; y++) {
    for(int yy=0; yy<zoom; yy++) {
      for(int x=0; x<8; x++) {
        if(charData[y] & (1<<(7-x))) {
          for(int xx=0; xx<zoom; xx++)
            drawPixel(x0 + x*zoom + xx, y0 + y*zoom + yy);
        }
      }
    }
  }
}

void drawFloat(float number, int x0, int y0) {
  char buf[10];
  dtostrf(number, 0, 2, buf); // 2 décimales
  int x = x0;
  for(int i=0; buf[i]!='\0'; i++) {
    if(buf[i]>='0' && buf[i]<='9') drawCharZoomBuffer(x, y0, digits[buf[i]-'0'], scale);
    else if(buf[i]=='.') drawCharZoomBuffer(x, y0, dot, scale);
    x += 8 * scale;
  }
}

  
void setup() {
  Wire.begin(OLED_SDA, OLED_SCL);
  ssd1306Init();
  clearBuffer();
  updateScreen();
}

void loop() {
  
  unsigned long now = millis();
float tension = getVoltage();
float courant = getCurrent();
float watt = tension * courant;
  
  if(now - lastUpdate >= interval) {
    lastUpdate = now;

    clearBuffer();           // efface l'écran
    drawFloat(tension, 0, 32); // affiche la nouvelle valeur
    drawFloat(courant, 0, 0); // affiche la nouvelle valeur
    updateScreen();

  }
}
