#define Initialisation_h


#define OLED_SDA 4
#define OLED_SCL 15
#define OLED_RST 16
#define SSD1306_I2C_ADDR 0x3C

int scale = 3; // Facteur de zoom

// Buffer écran : 8 pages × 128 colonnes
uint8_t screenBuffer[8][128];

// ---- Fonctions SSD1306 ----
void ssd1306Command(uint8_t command){
  Wire.beginTransmission(SSD1306_I2C_ADDR);
  Wire.write(0x00);
  Wire.write(command);
  Wire.endTransmission();
}

void ssd1306Data(uint8_t data){
  Wire.beginTransmission(SSD1306_I2C_ADDR);
  Wire.write(0x40);
  Wire.write(data);
  Wire.endTransmission();
}

void ssd1306Init(){
  Wire.begin();
  pinMode(OLED_RST, OUTPUT);
  digitalWrite(OLED_RST, LOW);
  delay(10);
  digitalWrite(OLED_RST, HIGH);

ssd1306Command(0xAE); // Display OFF – éteint l'écran pendant l'initialisation
ssd1306Command(0x20); // Set Memory Addressing Mode – définit le mode d'adressage de la mémoire
ssd1306Command(0x00); // Horizontal Addressing Mode – mode horizontal
ssd1306Command(0xB0); // Set Page Start Address for Page Addressing Mode – sélection de la page 0
ssd1306Command(0xC8); // COM Output Scan Direction – inversion verticale des lignes (remontée)
ssd1306Command(0x00); // Set Lower Column Start Address – colonne de départ basse à 0
ssd1306Command(0x10); // Set Higher Column Start Address – colonne de départ haute à 0
ssd1306Command(0x40); // Set Display Start Line – ligne de départ à 0
ssd1306Command(0x81); // Set Contrast Control – commande du contraste
ssd1306Command(0xFF); // Contraste maximal
ssd1306Command(0xA1); // Segment Re-map – inversion horizontale des colonnes
ssd1306Command(0xA6); // Normal Display – pixels 1 = allumé, 0 = éteint (pas d’inversion)
ssd1306Command(0xA8); // Set Multiplex Ratio – nombre de lignes multiplexées
ssd1306Command(0x3F); // Multiplex 64 (0x3F + 1 = 64 lignes)
ssd1306Command(0xA4); // Display RAM – afficher ce qui est dans la RAM
ssd1306Command(0xD3); // Set Display Offset – décalage vertical de l’affichage
ssd1306Command(0x00); // Offset = 0
ssd1306Command(0xD5); // Set Display Clock Divide Ratio/Oscillator Frequency
ssd1306Command(0xF0); // Diviseur / fréquence de l’oscillateur
ssd1306Command(0xD9); // Set Pre-charge Period – période de pré-charge
ssd1306Command(0x22); // Valeur du registre de pré-charge
ssd1306Command(0xDA); // Set COM Pins Hardware Configuration
ssd1306Command(0x12); // Configuration des pins COM
ssd1306Command(0xDB); // Set VCOMH Deselect Level – tension VCOMH
ssd1306Command(0x20); // Niveau VCOMH
ssd1306Command(0x8D); // Charge Pump Setting – active le régulateur interne
ssd1306Command(0x14); // Enable charge pump
ssd1306Command(0xAF); // Display ON – allume l’écran
}
